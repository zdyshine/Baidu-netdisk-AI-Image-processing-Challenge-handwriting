cd res/WithMaskOutput
zip -r result.zip *
mv result.zip ../../
cd ../..